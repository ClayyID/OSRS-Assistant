package com.example.osrsassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.floor

private val Bg = Color(0xFF101419)
private val Panel = Color(0xFF1C242D)
private val Panel2 = Color(0xFF252F3A)
private val Gold = Color(0xFFE8BD64)
private val Muted = Color(0xFFAAB4C0)
private val TextMain = Color(0xFFF3F5F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OsrsApp() }
    }
}

private enum class Page(val label: String) {
    HOME("Home"), TRACKER("XP Tracker"), CALCULATOR("XP Calculator"),
    TOOLS("Tools"), SKILLS("Skills"), SETTINGS("Settings")
}

@Composable
fun OsrsApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, secondary = Gold, background = Bg,
            surface = Panel, onBackground = TextMain, onSurface = TextMain
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val entries = listOf(Page.HOME, Page.TRACKER, Page.CALCULATOR, Page.TOOLS, Page.SKILLS)
                    entries.forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        Page.HOME -> Icons.Default.Home
                                        Page.TRACKER -> Icons.Default.ShowChart
                                        Page.CALCULATOR -> Icons.Default.Calculate
                                        Page.TOOLS -> Icons.Default.Timer
                                        else -> Icons.Default.MenuBook
                                    }, contentDescription = item.label
                                )
                            },
                            label = { Text(item.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Panel2, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("OSRS ASSISTANT", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("OLD SCHOOL RUNESCAPE COMPANION", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                    IconButton(onClick = { page = Page.SETTINGS }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Gold)
                    }
                }
                when (page) {
                    Page.HOME -> HomeScreen(
                        onNavigate = { page = it }
                    )
                    Page.TRACKER -> TrackerScreen()
                    Page.CALCULATOR -> CalculatorScreen()
                    Page.TOOLS -> ToolsScreen()
                    Page.SKILLS -> SkillsScreen()
                    Page.SETTINGS -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onNavigate: (Page) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("YOUR ADVENTURE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Plan. Track. Improve.", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("A standalone companion for your OSRS goals.", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatBox("TOTAL XP", "Set in tracker", Modifier.weight(1f))
                        StatBox("TARGET", "Your next level", Modifier.weight(1f))
                    }
                }
            }
        }
        item { Text("QUICK ACCESS", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        items(listOf(
            Triple("XP Tracker", "Record your skill progress", Icons.Default.ShowChart) to Page.TRACKER,
            Triple("XP Calculator", "Calculate XP to your goal", Icons.Default.Calculate) to Page.CALCULATOR,
            Triple("Session & Interval Timer", "Track a play session or interval", Icons.Default.Timer) to Page.TOOLS,
            Triple("Skill Database", "Browse all 23 OSRS skills", Icons.Default.MenuBook) to Page.SKILLS
        )) { (entry, target) ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onNavigate(target) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(entry.third, contentDescription = null, tint = Gold, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(entry.first, color = TextMain, fontWeight = FontWeight.SemiBold)
                        Text(entry.second, color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
                }
            }
        }
        item {
            Text(
                "Note: This app tracks and times activity locally. It does not automate gameplay inputs or interact with the OSRS client.",
                color = Muted, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun StatBox(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel2, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TrackerScreen() {
    var skill by remember { mutableStateOf("Attack") }
    var xp by remember { mutableStateOf("0") }
    var goal by remember { mutableStateOf("100000") }
    var saved by remember { mutableStateOf(false) }
    val current = xp.toLongOrNull()?.coerceAtLeast(0) ?: 0L
    val target = goal.toLongOrNull()?.coerceAtLeast(0) ?: 0L
    val progress = if (target > 0) (current.toFloat() / target).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("XP TRACKER", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("Record your progress", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Skill", color = Muted)
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }) { Text(skill, color = Gold); Icon(Icons.Default.ArrowDropDown, null) }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        skills.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { skill = it; expanded = false }) }
                    }
                }
                NumberField("Current XP", xp) { xp = it; saved = false }
                NumberField("Goal XP", goal) { goal = it; saved = false }
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Panel2)
                Text("${(progress * 100).toInt()}% • ${((target - current).coerceAtLeast(0)).toString()} XP remaining", color = Muted, fontSize = 12.sp)
                Button(onClick = { saved = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (saved) "Progress recorded for this session" else "Record progress")
                }
                Text("Demo build: entries are held in memory and reset when the app restarts.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun CalculatorScreen() {
    var levelText by remember { mutableStateOf("1") }
    var targetText by remember { mutableStateOf("99") }
    val level = (levelText.toIntOrNull() ?: 1).coerceIn(1, 99)
    val target = (targetText.toIntOrNull() ?: 99).coerceIn(1, 99)
    val valid = target >= level
    val currentXp = xpForLevel(level)
    val targetXp = xpForLevel(target)
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("XP CALCULATOR", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("Plan your next milestone", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                NumberField("Current level (1–99)", levelText) { levelText = it }
                NumberField("Target level (1–99)", targetText) { targetText = it }
                if (valid) {
                    Text("XP at level $level: ${currentXp.toString().formatThousands()}", color = Muted)
                    Text("XP at level $target: ${targetXp.toString().formatThousands()}", color = Muted)
                    Divider(color = Panel2)
                    Text("XP NEEDED", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text((targetXp - currentXp).toString().formatThousands(), color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                } else {
                    Text("Target level must be equal to or higher than current level.", color = Color(0xFFFF8A80))
                }
                Text("Uses the standard OSRS level XP curve.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ToolsScreen() {
    var seconds by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var interval by remember { mutableStateOf("60") }
    var ticks by remember { mutableIntStateOf(0) }
    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            seconds++
        }
    }
    LaunchedEffect(running, interval) {
        val every = (interval.toIntOrNull() ?: 60).coerceIn(1, 3600)
        while (running) {
            delay(every * 1000L)
            ticks++
        }
    }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("TOOLS", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("Session & interval timer", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SESSION DURATION", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(formatTime(seconds), color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Black)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { running = !running }) { Text(if (running) "Pause" else "Start") }
                    OutlinedButton(onClick = { running = false; seconds = 0; ticks = 0 }) { Text("Reset") }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("INTERVAL REMINDER", color = Gold, fontWeight = FontWeight.Bold)
                NumberField("Interval in seconds", interval) { interval = it }
                Text("Reminder count: $ticks", color = TextMain)
                Text("This is a timer/notification counter only. It does not click or send touch input.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SkillsScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("SKILL DATABASE", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("All 23 Old School RuneScape skills", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
        }
        items(skills) { skill ->
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Star, null, tint = Gold)
                Spacer(Modifier.width(12.dp))
                Text(skill, color = TextMain, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Text("Level 1–99", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SETTINGS", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("App preferences", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SettingRow("Appearance", "Dark theme")
                SettingRow("Layout", "Standalone")
                SettingRow("Data storage", "Session-only demo")
                SettingRow("Version", "1.0.0")
            }
        }
        Text("OSRS Assistant is an unofficial companion app and is not affiliated with Jagex.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, color = Muted)
        Text(value, color = TextMain, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(it.filter(Char::isDigit).take(12)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold, focusedLabelColor = Gold,
            unfocusedBorderColor = Panel2, unfocusedLabelColor = Muted,
            focusedTextColor = TextMain, unfocusedTextColor = TextMain
        )
    )
}

private val skills = listOf(
    "Attack", "Strength", "Defence", "Ranged", "Prayer", "Magic", "Runecraft",
    "Hitpoints", "Crafting", "Mining", "Smithing", "Fishing", "Cooking",
    "Firemaking", "Woodcutting", "Agility", "Herblore", "Thieving", "Fletching",
    "Slayer", "Farming", "Construction", "Hunter"
)

private fun xpForLevel(level: Int): Long {
    if (level <= 1) return 0L
    var points = 0.0
    for (lvl in 1 until level) {
        points += floor(lvl + 300.0 * Math.pow(2.0, lvl / 7.0))
    }
    return floor(points / 4.0).toLong()
}

private fun Long.formatThousands(): String = String.format(Locale.US, "%,d", this)
private fun formatTime(total: Int): String {
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
